-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 16, 2026 at 04:50 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rental-kamera-lara`
--

-- --------------------------------------------------------

--
-- Table structure for table `alats`
--

CREATE TABLE `alats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kategori_id` bigint(20) UNSIGNED NOT NULL,
  `nama_alat` varchar(255) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `harga24` int(11) NOT NULL,
  `harga12` int(11) NOT NULL,
  `harga6` int(11) NOT NULL,
  `gambar` varchar(255) NOT NULL DEFAULT 'noimage.jpg',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `alats`
--

INSERT INTO `alats` (`id`, `kategori_id`, `nama_alat`, `deskripsi`, `harga24`, `harga12`, `harga6`, `gambar`, `created_at`, `updated_at`) VALUES
(1, 1, 'Sony a7ii', 'Kamera dengan HD Dimensi', 200000, 175000, 125000, '1649951685-Sony-A7-Mark-II-Body-Only-a.jpg', NULL, '2026-01-14 03:32:14'),
(2, 1, 'Sony a6000', 'Sony a6000', 100000, 80000, 50000, '1649951696-21833_L_1.jpg', NULL, '2026-01-16 03:07:42'),
(3, 1, 'Canon EOS 550D', 'Canon EOS 550D', 85000, 75000, 60000, '1649951709-550d.jpg', NULL, '2026-01-16 03:07:49'),
(4, 2, 'Sigma 30mm 1.4 for Sony', 'Sigma 30mm 1.4 for Sony', 100000, 80000, 50000, '1649951742-sigma 30mm.jpg', NULL, '2026-01-16 03:07:55'),
(5, 2, 'Sigma 16mm 1.4 for Sony', 'Sigma 16mm 1.4 for Sony', 100000, 80000, 50000, '1649951751-images.jpg', NULL, '2026-01-16 03:08:01'),
(6, 2, 'Canon EF 50mm 1.4 USM', 'Canon EF 50mm 1.4 USM', 75000, 60000, 50000, '1649951760-50mm canon usm.jpg', NULL, '2026-01-16 03:08:09'),
(7, 3, 'Yongnuo 560 IV', 'Yongnuo 560 IV', 125000, 90000, 75000, '1649951771-YONGNUO-YN560-IV-a.jpg', NULL, '2026-01-16 03:08:53'),
(8, 4, 'DJI Ronin SC', 'DJI Ronin SC', 175000, 150000, 100000, '1649951821-dji_rsc_2_ready_gan.jpg', NULL, '2026-01-16 03:09:03'),
(9, 1, 'Kamera Mirrorless Canon EOS M10', 'Tidak ingin latah seperti umumnya mirrorless yakni dengan desain retro', 250000, 150000, 100000, '1768440234-canon-eos-m10-299-m10c.png', '2026-01-15 01:23:54', '2026-01-16 03:08:37'),
(10, 5, 'Kamera Video Sony HXR MC88', 'Sony HXR-MC88 Full HD Camcorder dirancang untuk education, government, dan individu yang membutuhkan solusi kamera HD yang ringan.', 350000, 250000, 150000, '1768440971-sony-hxr-mc88-270-sewa kamera sony mc88.png', '2026-01-15 01:36:11', '2026-01-16 03:09:16'),
(11, 5, 'Kamera Video Sony HDR CX210 Full HD', 'High Definition, MPEG AVC/H.264, 1920 x 1080i / 60 fps', 270000, 200000, 150000, '1768441355-sony-hdr-cx210-full-hd-99-Sony-CX210.png', '2026-01-15 01:42:35', '2026-01-15 01:42:35'),
(12, 5, 'Kamera Video Sony HVR Z7', 'General\r\n    Packaged Quantity 1\r\n    Product Type Camcorder – 1080p', 240000, 180000, 130000, '1768441539-sony-hvr-z7-803-Sony HVR Z7b.png', '2026-01-15 01:45:39', '2026-01-16 03:09:33'),
(13, 5, 'Kamera Video DJI Osmo 4K Wifi', 'Paket Sewa: Unit DJI Osmo, Dekstop Charger, Baterai 2, Memory 64 GB & Tas.', 280000, 180000, 100000, '1768441696-dji-osmo-4k-wifi-57-DJI Osmo 4K Wifi.png', '2026-01-15 01:48:16', '2026-01-15 01:48:16'),
(14, 4, 'Tripod Brica B-Pro SteadyCam For Phone', 'Sewa Brica B-Steady Pro 3-Axis Smartphone Gimbal dapat memberikan lebih banyak flexibility dan versatility dalam meredam guncangan ketika Anda merekam gambar dan membuat hasil video menjadi cinematic yang mengagumkan.', 215000, 150000, 100000, '1768442183-brica-bpro-steadycam-for-phone-689-brica b-pro steadicam.png', '2026-01-15 01:56:23', '2026-01-16 03:10:00'),
(15, 4, 'Tripod Excell UFO 266', 'Sewa Peralatan Tripod Excell UFO 266', 150000, 100000, 60000, '1768442392-excell-ufo-266-627-Excell UFO 266.png', '2026-01-15 01:59:52', '2026-01-15 01:59:52'),
(16, 4, 'Tripod Tripod Takara', 'Sewa Peralatan Tripod Tripod Takara', 165000, 100000, 70000, '1768442516-tripod-takara-815-Tripod Takara.png', '2026-01-15 02:01:56', '2026-01-15 02:01:56'),
(17, 2, 'Lensa Canon Canon 70-200mm f2.8 Mark II', 'Sewa lensa kamera Canon L Series ini di IFrame Rental. Lensa yang benar-benar serbaguna, EF 70-200mm f / 2.8L USM adalah zoom seri-L Canon yang mencakup rentang fleksibel panjang fokus telefoto.', 270000, 180000, 100000, '1768443006-canon-70200mm-f28-mark-ii-710-Canon 70-200mm f2_8 Mark II 01.png', '2026-01-15 02:10:06', '2026-01-16 03:10:29'),
(18, 2, 'Lensa Canon Canon EF 70-200mm f/2.8 L', 'Canon memiliki empat versi lensa telefoto 70-200mm L. Secara umum, kualitas lensa berlabel L (Luxury/mewah) ini sangat baik. Lensa ini mudah dikenali karena berwarna putih krim.', 170000, 100000, 80000, '1768443169-canon-ef-70200mm-f28-l-564-Canon EF 70-200mm f2-8 Lb.png', '2026-01-15 02:12:49', '2026-01-16 03:10:46'),
(19, 2, 'Canon SIGMA for Canon 35mm f/1.4 DG', 'Sewa Lensa kamera 35mm f/1.4 DG HSM Art didukung dengan floating inner focus dan juga aperture f/1.4 yang menjadi andalan Sigma dalam menghasilkan kualitas foto  video yang memiliki warna lebih kaya dan detail tajam.', 180000, 100000, 60000, '1768443313-sigma-for-canon-35mm-f14-dg-804-Sewa lensa Sigma 18-35mm F1 8 DC HSM jogja.png', '2026-01-15 02:15:13', '2026-01-16 03:37:19'),
(20, 1, 'DSLR Canon EOS 700D', 'Kamera DSLR keluaran terbaru dari Canon ini tampaknya memang ditawarkan pada fotografer pemula yang ingin membawa fotografi mereka ke tingkat lebih lanjut.', 150000, 100000, 60000, '1768443898-canon-eos-700d-130-c700dc.png', '2026-01-15 02:20:37', '2026-01-16 03:11:16'),
(21, 1, 'DSLR Canon EOS 3000D', 'EOS 3000D dilengkapi dengan banyak fungsi pemotretan penting yang sudah melekat pada kamera EOS. Autofocusing (AF) cepat dapat dengan mudah diperoleh dengan AF 9 titik yang memiliki titik AF tipe silang di bagian tengah.', 230000, 150000, 100000, '1768444378-canon-eos-3000d-731-sewa canon 3000d jogja.png', '2026-01-15 02:32:58', '2026-01-16 03:11:39'),
(22, 1, 'Mirrorless Fujifilm X-A2 Kit', 'Lens Mount  Fujifilm X Mount Camera Format 	APS-C (1.5x Crop Factor) Pixels 	Actual: 16.5 Megapixel Effective: 16.3 Megapixel.', 270000, 150000, 100000, '1768448405-fujifilm-xa2-kit-774-xa2.png', '2026-01-15 03:40:05', '2026-01-15 03:40:05'),
(23, 1, 'Mirrorless Fujifilm X-A3 Kit', 'Kamera Mirrorless Fujifilm XA3 – FujiFilm XA3 kit 16-50mm Hadir dengan 3 Varian warna yang dapat kamu pilih sesuai dengan warna favoritmu, antara lain: Silver, Brown dan Pink yang menampilkan desain retro menarik bagi generasi muda.', 230000, 150000, 100000, '1768448625-fujifilm-xa3-kit-327-sewa kamera jogja fujifilm x-a3.png', '2026-01-15 03:43:45', '2026-01-16 03:36:54'),
(24, 3, 'Lighting Godox LED SL 150W', 'Sewa Lighting Godox SL150w sebagai sumber cahaya serbaguna yang sangat cocok untuk profesional fotografi dan video. Lampu LED SL-150W dari Godox ini merupakan lampu bertemperatur warna 5600K.', 170000, 100000, 80000, '1768449197-godox-led-sl-150w-476-godox sl150w 2.png', '2026-01-15 03:53:17', '2026-01-16 03:12:12'),
(25, 3, 'Lighting Paket Lighting Mini Studio Flash Godox @75watt', 'Sewa Godox Mini Pioneer 160 Kits Lampu Studio [Paket] di IFRAME Rental Kamera. Ini merupakan lighting studio mini yang didesain praktis dan ringan.', 190000, 100000, 70000, '1768449769-paket-lighting-mini-studio-flash-godox-75watt-875-sewa Paket Lighting Mini Studio Flash Godox @75watt.png', '2026-01-15 04:02:49', '2026-01-16 03:12:29'),
(26, 3, 'Lighting Canon Speedlite 430 EX II', 'Sewa Peralatan Lighting Canon Speedlite 430 EX II', 125000, 76000, 40000, '1768450547-canon-speedlite-430-ex-ii-405-Canon Speedlite 430 EX IIb.png', '2026-01-15 04:15:47', '2026-01-15 04:15:47'),
(27, 3, 'Lighting LED YN600', 'Paket Sewa: Unit Lampu LED (1), Baterai Np-F750 (2), Remote, Filter (2) dan Lighstand.', 155000, 70000, 45000, '1768450756-led-yn600-370-LED YN600a.png', '2026-01-15 04:19:16', '2026-01-16 03:12:45'),
(28, 1, 'Kamera Action Cam DJI OSMO POCKET 3 COMBO', 'DJI Osmo Pocket 3 Creator Combo adalah kamera saku dengan sensor CMOS 1 inci yang mampu merekam video 4K pada berbagai kecepatan bingkai, termasuk 120fps untuk gerakan lambat.', 285000, 200000, 150000, '1768525015-dji-osmo-pocket-3-combo-520-DJI Osmo Pocket 3 02.png', '2026-01-16 00:56:55', '2026-01-16 03:12:58'),
(30, 1, 'GoPro Hero 3+ Black Edition', 'Aksesoris Tambahan:\r\n    Headstrap: 15.000\r\n    Baterai Extra: 25.000 (+Charger Wasabi)\r\n    Mount Tripod: 10.000', 900000, 50000, 30000, '1768525484-12.png', '2026-01-16 01:04:44', '2026-01-16 03:13:14'),
(31, 1, 'Xiaomi Yi II 4K', 'Sewa Xiaomi YI II 4K di Jogja, kamera ini merupakan action camera dari YI Technologi. Action Cam Xiaomi YI II 4K punya spesifikasi tinggi yang dapat merekam video 4K UHD.', 90000, 50000, 35000, '1768525872-xiaomi-yi-ii-4k-117-sewa xiaomi yi ii 4k jogja.png', '2026-01-16 01:11:12', '2026-01-16 03:13:32'),
(32, 4, 'Zhiyun Tech Weebill S', 'Zhiyun WeeBill Lab Handheld Stabilizer untuk Kamera Mirrorless, mendukung kamera yang beratnya mencapai 3 kilogram.', 250000, 170000, 130000, '1768526152-zhiyun-tech-weebill-s-794-sewa zhiyun weebill-s jogja.png', '2026-01-16 01:15:52', '2026-01-16 03:13:41');

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `alat_id` bigint(20) UNSIGNED NOT NULL,
  `harga` int(11) NOT NULL,
  `durasi` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama_kategori` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `nama_kategori`, `created_at`, `updated_at`) VALUES
(1, 'Kamera', NULL, NULL),
(2, 'Lensa', NULL, NULL),
(3, 'Lighting', NULL, NULL),
(4, 'Stabilizer', NULL, NULL),
(5, 'Video', '2026-01-15 01:32:23', '2026-01-15 01:32:23');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2022_02_15_140424_create_categories_table', 1),
(5, '2022_02_15_154902_create_alats_table', 1),
(6, '2022_04_09_065246_create_carts_table', 1),
(7, '2022_04_13_135055_create_payments_table', 1),
(8, '2022_04_13_142930_create_orders_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `alat_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `payment_id` bigint(20) UNSIGNED NOT NULL,
  `durasi` int(11) NOT NULL,
  `starts` datetime NOT NULL,
  `ends` datetime NOT NULL,
  `harga` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `alat_id`, `user_id`, `payment_id`, `durasi`, `starts`, `ends`, `harga`, `status`, `created_at`, `updated_at`) VALUES
(1, 2, 4, 1, 24, '2026-01-13 10:30:00', '2026-01-14 10:30:00', 100000, 2, '2026-01-13 03:07:48', '2026-01-13 03:09:19'),
(2, 2, 4, 1, 24, '2026-01-13 10:30:00', '2026-01-14 10:30:00', 100000, 2, '2026-01-13 03:07:48', '2026-01-13 03:09:19');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `no_invoice` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `total` int(11) NOT NULL,
  `bukti` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `no_invoice`, `user_id`, `total`, `bukti`, `status`, `created_at`, `updated_at`) VALUES
(1, '4/1768273668', 4, 200000, '1768273817-Slip Bayarrr.png', 4, '2026-01-13 03:07:48', '2026-01-13 07:08:11');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `telepon` varchar(255) DEFAULT NULL,
  `role` tinyint(4) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `telepon`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@gmail.com', NULL, '$2b$12$S2XUkS7s0oZUsdj5B4/L3ew9ICzZQX.R./6EB2./1tJ4ihyBUtx52', NULL, 2, NULL, NULL, NULL),
(2, 'pegawai', 'pegawai@gmail.com', NULL, '$2b$12$Qc.OLvCzU2/ZhREWEFK2KO3F4rhWBIZJmGjAmYhVnIEWL.wGdH/Dm', NULL, 1, NULL, NULL, NULL),
(4, 'kasep', 'kasep@gmail.com', NULL, '$2y$10$JwPHRK5M6teJ6mcpA0BiiO2K4inpxWunKaYPPECS6sBcPNe6x8tZG', '0812232323', 0, NULL, '2026-01-13 03:04:31', '2026-01-13 03:04:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alats`
--
ALTER TABLE `alats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alats_kategori_id_foreign` (`kategori_id`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `carts_user_id_foreign` (`user_id`),
  ADD KEY `carts_alat_id_foreign` (`alat_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_alat_id_foreign` (`alat_id`),
  ADD KEY `orders_user_id_foreign` (`user_id`),
  ADD KEY `orders_payment_id_foreign` (`payment_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payments_user_id_foreign` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alats`
--
ALTER TABLE `alats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `alats`
--
ALTER TABLE `alats`
  ADD CONSTRAINT `alats_kategori_id_foreign` FOREIGN KEY (`kategori_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `carts_alat_id_foreign` FOREIGN KEY (`alat_id`) REFERENCES `alats` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `carts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_alat_id_foreign` FOREIGN KEY (`alat_id`) REFERENCES `alats` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_payment_id_foreign` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
